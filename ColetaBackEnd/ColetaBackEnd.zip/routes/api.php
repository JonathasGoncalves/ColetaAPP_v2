<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Providers\RouteServiceProvider;
use App\Http\Controllers\Auth\RegisterController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::namespace('Api')->name('api.')->group(function () {
    Route::prefix('coleta')->group(function () {
        Route::post('/revokeToken', 'ColetaController@revokeToken')->name('revokeToken');
        Route::post('/RetornaCoordenada/{id_coleta}', 'ColetaController@RetornaCoordenada')->name('RetornaCoordenada'); //recebe id coleta
    });
});


//middleware(['client'])->
Route::middleware(['client'])->namespace('Api')->name('api.')->group(function () {

    Route::prefix('transportadora')->group(function () {
        Route::post('/verificarPlaca', 'TransportadoraController@verificarPlaca')->name('verificarPlaca');
        Route::post('/reboqueList', 'TransportadoraController@reboqueList')->name('reboqueList');
    });

    Route::prefix('linha')->group(function () {
        Route::post('/linhasPorVeiculo', 'LinhaController@linhasPorVeiculo')->name('linhasPorVeiculo');
    });

    Route::prefix('tanque')->group(function () {
        Route::post('/TanquesInLinhas', 'TanqueController@TanquesInLinhas')->name('TanquesInLinhas');
    });

    Route::prefix('coleta')->group(function () {
        Route::post('/NovaColeta', 'ColetaController@NovaColeta')->name('NovaColeta');
        Route::post('/NovaColetaItem', 'ColetaController@NovaColetaItem')->name('NovaColetaItem');
        Route::get('/RetornaColetaPesagem/{id_coleta}', 'ColetaController@RetornaColetaPesagem')->name('RetornaColetaPesagem'); //recebe id coleta
        Route::get('/coletaEmAberto', 'ColetaController@coletaEmAberto')->name('coletaEmAberto');
        Route::get('/RetornaOcorrencia/{id_coleta}', 'ColetaController@RetornaOcorrencia')->name('RetornaOcorrencia');
        Route::post('/coletaEmAbertoPorVeiculo', 'ColetaController@coletaEmAbertoPorVeiculo')->name('coletaEmAbertoPorVeiculo');
        Route::get('/coletaEmAbertoPorPlaca/{placa}', 'ColetaController@coletaEmAbertoPorPlaca')->name('coletaEmAbertoPorPlaca');
        Route::get('/finalizarColetaImport/{id_coleta}/{id_pesagem}', 'ColetaController@finalizarColetaImport')->name('finalizarColetaImport');
        Route::get('/estornoColeta/{id_pesagem}', 'ColetaController@EstornoColeta')->name('EstornoColeta');
        Route::post('/RemoverColeta', 'ColetaController@RemoverColeta')->name('RemoverColeta');
    });
});
