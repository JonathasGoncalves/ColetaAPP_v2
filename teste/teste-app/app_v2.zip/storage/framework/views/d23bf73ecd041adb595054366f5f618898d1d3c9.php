<figure>
     <img src="logo.png" alt="Minha Figura">
</figure><?php /**PATH C:\Users\jonathas.picoli\Documents\Desenvolvimento\ProjetoAPPColeta\teste\teste-app\resources\views/components/application-logo.blade.php ENDPATH**/ ?>