<html>
  <head> 
  </head>
  <body>
    <div >
      <div >
        <ul>
          <li><a href="/">Finalizar</a></li>
        </ul>
      </div>
    </div>
  </body>
</html><?php /**PATH C:\Users\jonathas.picoli\Documents\Desenvolvimento\ProjetoAPPColeta\teste\teste-app\resources\views\habilitar\aprovar_solicitacao.blade.php ENDPATH**/ ?>