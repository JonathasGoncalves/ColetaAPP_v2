<div class="w-full flex justify-center">
  <?php echo e($aprovarBtn); ?>

  <?php if($aprovado == "false"): ?>
  <form class="w-1/4" wire:submit.prevent="aprovar_solicitacao()">
    <div class="flex flex-col w-full mb-8 mt-2">
      <label class="p-4 font-semibold w-full" for="motorista_identificacao">Identifique o motorista</label>

      <select class="rounded w-full" wire:change="selecionar_mot($event.target.value)">
        <option class="rounded w-full" value="000000"></option>
        <?php $__currentLoopData = $motoristas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option class="rounded w-full" value="<?php echo e($motorista['COD_MOTORISTA']); ?>">
          <?php echo e($motorista['NOME_MOTORISTA']); ?>

        </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <?php if($motorista_completo <> null): ?>
      <label class="p-4 font-semibold w-full" for="motorista" for="transportadora">Transportadora:</label><br>
      <input class="w-full mb-4 mt-2 rounded" type="text" id="transportadora" value="<?php echo e($motorista_completo['TRANSPORTADORA']); ?>" disabled><br><br>

      <label class="p-4 font-semibold w-full" for="motorista" for="cpf">CPF:</label><br>
      <input class="w-full mb-4 mt-2 rounded" type="text" id="cpf" value="<?php echo e($motorista_completo['CPF']); ?>" disabled><br><br>

      <label class="p-4 font-semibold w-full" for="motorista" for="rg">RG:</label><br>
      <input class="w-full mb-4 mt-2 rounded" type="text" id="rg" value="<?php echo e($motorista_completo['RG']); ?>" disabled><br><br>

      <label class="p-4 font-semibold w-full" for="motorista" for="cnh">CNH:</label><br>
      <input class="w-full mb-4 mt-2 rounded" type="text" id="cnh" value="<?php echo e($motorista_completo['CNH']); ?>" disabled><br><br>

      <label class="p-4 font-semibold w-full" for="motorista" for="telefone">Telefone:</label><br>
      <input class="w-full mb-4 mt-2 rounded" type="text" id="telefone" value="<?php echo e($motorista_completo['TELEFONE']); ?>" disabled><br><br>

      <label class="font-semibold w-full">Placas</label><br>
      <div class="border border-gray-600 w-full rounded mb-4 mt-2 grid justify-items-start ">
        <ul class="mb-4 list-disc list-inside">
          <?php $__currentLoopData = $motorista_completo['PLACAS']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $placa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="ml-4 mt-2 rounded"><?php echo e($placa); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <?php endif; ?>
      <div class="flex flex-col self-center items-center">

        <div wire:loading>
          <h1 class="text-yellow-500 font-semibold text-2xl animate-pulse mb-8">Carregando...</h1>
        </div>
        <?php if($aprovarBtn): ?>
        <input class="rounded bg-yellow-500 w-40 h-14 text-white" type="submit" value="Aprovar">
        <?php else: ?>
        <input disabled class="rounded bg-yellow-500 w-40 h-14 text-white" type="submit" value="Aprovar">
        <?php endif; ?>
      </div>

  </form>
  <?php else: ?>
  <div wire:poll.750ms="atualizar_aparelho"></div>
  <?php if($aparelho['habilitado'] == 'false'): ?>
  <div class=" flex items-center flex-col mt-40">
    <h1 class="font-semibold text-2xl mb-8">Leia o QrCode para acessar o aplicativo</h1>
    <div class="h-auto">
      <?php echo QrCode::size(350)->backgroundColor(255, 255, 255)->generate($solicitacao['MAC']);; ?>

    </div>
  </div>
  <?php else: ?>
  <div class="flex items-center flex-col mt-40">
    <h1 class=" font-semibold text-2xl mb-8">Acesso liberado!</h1>
    <button id="btn-aprovar" class="rounded bg-yellow-500 w-40 h-14 text-white" wire:click="retornar()">
      Continuar
    </button>
  </div>

  <?php endif; ?>

  <?php endif; ?>
</div><?php /**PATH C:\Users\jonathas.picoli\Documents\Desenvolvimento\ProjetoAPPColeta\teste\teste-app\resources\views/livewire/edit-solicitacoes.blade.php ENDPATH**/ ?>