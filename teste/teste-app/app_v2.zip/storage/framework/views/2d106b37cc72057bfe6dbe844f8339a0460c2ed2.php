    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>Listagem de Solicitações</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"><?php /**PATH C:\Users\jonathas.picoli\Documents\Desenvolvimento\ProjetoAPPColeta\teste\teste-app\resources\views/includes/head.blade.php ENDPATH**/ ?>