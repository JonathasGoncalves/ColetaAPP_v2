<div class="container">
  <form action="/action_page.php">
  <div class="flex flex-col w-1/4 mb-8 mt-2"> 
    <label class="p-4 font-semibold" for="motorista_identificacao">Identifique o motorista</label>

    <select class="rounded"  wire:change="selecionar_motorista('000015')">
      <?php $__currentLoopData = $motoristas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($motorista->COD_MOTORISTA); ?>"> 
          <?php echo e($motorista->NOME_MOTORISTA); ?>

        </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </select> 
  </div>
    <input class="rounded bg-yellow-500 w-40 h-14 text-white" type="submit" value="Aprovar">
  </form>   
</div><?php /**PATH C:\Users\jonathas.picoli\Documents\Desenvolvimento\ProjetoAPPColeta\teste\teste-app\resources\views\livewire\edit-solicitacoes.blade.php ENDPATH**/ ?>