    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>Listagem de Solicitações</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript">
        var $placas;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
         function alimentarCampo() {
            var minhaLista = document.getElementById("motorista");
            var payload = {
                "cod_motorista": minhaLista.options[minhaLista.selectedIndex].value
            };
            $.ajax({
               type:'POST',
               url:'/recuperar_motorista',
               data: payload,
               success:function(data) {
                    document.getElementById("transportadora").value = data.COD_MOTORISTA;
                    document.getElementById("cpf").value = data.CPF;
                    document.getElementById("rg").value = data.RG;
                    document.getElementById("cnh").value = data.CNH;
                    document.getElementById("telefone").value = data.TELEFONE;
                    $placas = data.PLACAS;
               }
            });
         }
      </script><?php /**PATH C:\Users\jonathas.picoli\Documents\Desenvolvimento\ProjetoAPPColeta\teste\teste-app\resources\views\includes\head.blade.php ENDPATH**/ ?>