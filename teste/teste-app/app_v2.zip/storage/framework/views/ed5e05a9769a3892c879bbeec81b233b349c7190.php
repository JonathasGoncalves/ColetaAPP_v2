<!doctype html>
<html>
    <head>
       <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body>
    <div class="h-full">
       <header>
           <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       </header>
       <div class="min-h-screen min-w-full flex justify-center"> 
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('solicitacoes', [])->html();
} elseif ($_instance->childHasBeenRendered('dVjlTa4')) {
    $componentId = $_instance->getRenderedChildComponentId('dVjlTa4');
    $componentTag = $_instance->getRenderedChildComponentTagName('dVjlTa4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dVjlTa4');
} else {
    $response = \Livewire\Livewire::mount('solicitacoes', []);
    $html = $response->html();
    $_instance->logRenderedChild('dVjlTa4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
       </div>
       <footer class="font-serif text-lg font-extralight align-middle text-center">
           <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       </footer>
    </div>
    <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>

<?php /**PATH C:\Users\jonathas.picoli\Documents\Desenvolvimento\ProjetoAPPColeta\teste\teste-app\resources\views\layouts\list.blade.php ENDPATH**/ ?>