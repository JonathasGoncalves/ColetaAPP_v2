<div class="min-h-screen min-w-full flex justify-center">
  <?php if($solicitacao == []): ?>
  <?php echo $__env->make("livewire.solicitacoes", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php else: ?>
  <?php echo $__env->make("livewire.edit-solicitacoes", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
</div><?php /**PATH C:\Users\jonathas.picoli\Documents\Desenvolvimento\ProjetoAPPColeta\teste\teste-app\resources\views/livewire/main.blade.php ENDPATH**/ ?>