<div class="font-serif mt-14">
  <ul class="grid grid-cols-3 list-none p-10 text-3xl p-4">
    <li class="p-4 text-center font-semibold border-2 border-black border-r-0">Solicitante</li>
    <li class="p-4 text-center font-semibold border-2 border-black border-r-0">Data Solicitação</li>
    <li class="p-4 text-center font-semibold border-2 border-black">Ações</li>
    <?php $__currentLoopData = $solicitacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="p-4 text-center  border-2 border-black border-r-0 border-t-0"><?php echo e($solicitacao->nome_digitado); ?></li>
    <li class="p-4 text-center  border-2 border-black border-r-0 border-t-0"><?php echo e($solicitacao->created_at); ?></li>
    <li class="p-4 text-center  border-2 border-black border-t-0">
      <div class="flex flex-row justify-evenly">
        <button wire:click="selecionar(<?php echo e($solicitacao->id); ?>)">
          <i class="fas fa-check-circle text-green-500"></i>
        </button>
        <button wire:click="excluir(<?php echo e($solicitacao->id); ?>)">
          <i class="fas fa-trash text-red-500"></i>
        </button>
      </div>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div><?php /**PATH C:\Users\jonathas.picoli\Documents\Desenvolvimento\ProjetoAPPColeta\teste\teste-app\resources\views/livewire/solicitacoes.blade.php ENDPATH**/ ?>