<div class="font-sans">
    <h1 class="text-4xl font-semibold text-center p-10 bg-yellow-500 text-white">Controle de Acesso</h1>
</div>

<?php /**PATH C:\Users\jonathas.picoli\Documents\Desenvolvimento\ProjetoAPPColeta\teste\teste-app\resources\views\includes\header.blade.php ENDPATH**/ ?>