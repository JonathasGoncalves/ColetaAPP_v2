<?php return array (
  'edit-solicitacoes' => 'App\\Http\\Livewire\\EditSolicitacoes',
  'solicitacoes' => 'App\\Http\\Livewire\\Solicitacoes',
);