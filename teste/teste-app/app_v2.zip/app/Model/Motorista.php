<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Motorista extends Model
{
    protected $table = 'Motorista_Coleta';
    //protected $primaryKey = ['COD_MOTORISTA', 'stock_id'];
    //public $incrementing = false;
}
