<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Ocorrencia extends Model
{
    protected $table = 'item_ocorrencia';
    
}
