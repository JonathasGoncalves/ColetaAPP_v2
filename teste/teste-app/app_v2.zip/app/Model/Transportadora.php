<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Transportadora extends Model
{
    protected $table = 'transportadora';


}
