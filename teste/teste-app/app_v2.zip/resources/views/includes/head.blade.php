    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <title>Listagem de Solicitações</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">