<figure>
     <img src="logo.png" alt="Minha Figura">
</figure>