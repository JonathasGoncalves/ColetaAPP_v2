<div class="font-serif mt-14">
  <div class="flex flex-col justify-evenly">

    <form action="/solicitacoes" id="btn-solicitacoes">
      <input class="rounded bg-yellow-500 w-40 h-14 text-white my-10" type="submit" value="Solicitações" />
    </form>

    <form action="/coletores" id="btn-coletores">
      <input class="rounded bg-yellow-500 w-40 h-14 text-white my-10" type="submit" value="Coletores" />
    </form>

  </div>
</div>